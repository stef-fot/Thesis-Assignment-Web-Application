package myy803.diplomas_project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiplomasProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(DiplomasProjectApplication.class, args);
	}

}